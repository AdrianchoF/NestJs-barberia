import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

export enum Role {
  ADMINISTRADOR = 'administrador',
  BARBERO = 'barbero',
  CLIENTE = 'cliente',
}

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  nombre: string;

  @Column({ length: 100 })
  apellido: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column({ type: 'varchar', length: 15})
  telefono: string;

  @Column({
    type: 'enum',
    enum: Role,
    default: Role.CLIENTE
  })
  role:Role;

  @Column({ default: true })
  activo?: boolean;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;
}