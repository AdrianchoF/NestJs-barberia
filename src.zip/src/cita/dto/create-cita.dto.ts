export class CreateCitaDto {}
